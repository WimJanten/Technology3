#ifndef PARSEDATA_H
#define PARSEDATA_H

int GetSize(int *N);
int GetArray(int arr[], int size);
int GetK(int *K);

#endif
